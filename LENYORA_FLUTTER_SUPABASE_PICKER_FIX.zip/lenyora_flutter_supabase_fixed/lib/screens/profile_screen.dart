import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/auth_service.dart';
import '../widgets/app_button.dart';
import '../widgets/app_text_field.dart';
import '../theme/app_theme.dart';
import 'application_status_screen.dart';
import 'change_password_screen.dart';
import 'help_support_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  String _role = 'parent';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await AuthService().getMyProfile();
      _name.text = '${p['full_name'] ?? ''}';
      _phone.text = '${p['phone_number'] ?? ''}';
      _role = '${p['role'] ?? 'parent'}';
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load profile: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final user = Supabase.instance.client.auth.currentUser!;
      await Supabase.instance.client
          .from('profiles')
          .update({
            'full_name': _name.text.trim(),
            'phone_number': _phone.text.trim(),
          })
          .eq('auth_user_id', user.id);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile saved successfully.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save profile: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final email = Supabase.instance.client.auth.currentUser?.email ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('My Profile')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const SizedBox(height: 8),
                const CircleAvatar(
                  radius: 43,
                  backgroundColor: AppTheme.paleRose,
                  child: Icon(Icons.person_outline, size: 58, color: AppTheme.maroon),
                ),
                const SizedBox(height: 10),
                Text(_name.text.trim().isEmpty ? 'Parent / Guardian' : _name.text.trim(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                Text(email, textAlign: TextAlign.center, style: const TextStyle(decoration: TextDecoration.underline)),
                const SizedBox(height: 4),
                Text(_phone.text, textAlign: TextAlign.center),
                const SizedBox(height: 20),
                AppTextField(label: 'Full Name', controller: _name),
                AppTextField(label: 'Phone Number', controller: _phone, keyboardType: TextInputType.phone),
                AppButton(text: 'Save Profile', onPressed: _save, loading: _saving),
                const SizedBox(height: 18),
                _ProfileAction(icon: Icons.groups_2_outlined, title: 'My Applications', subtitle: 'View application progress and decisions', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ApplicationStatusScreen()))),
                _ProfileAction(icon: Icons.lock_outline, title: 'Change Password', subtitle: 'Update your account password', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChangePasswordScreen()))),
                _ProfileAction(icon: Icons.help_outline, title: 'Help & Support', subtitle: 'School contact details and FAQs', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpSupportScreen()))),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  icon: const Icon(Icons.logout, color: Colors.red),
                  label: const Text('Log Out', style: TextStyle(color: Colors.red)),
                  onPressed: () async {
                    await AuthService().signOut();
                  },
                ),
                const SizedBox(height: 8),
                Text('Account type: $_role', textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, fontSize: 12)),
              ],
            ),
    );
  }

}

class _ProfileAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ProfileAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: CircleAvatar(backgroundColor: AppTheme.paleRose, child: Icon(icon, color: AppTheme.maroon)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}
