import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../widgets/app_button.dart';
import 'application_wizard_screen.dart';

class ApplicationStatusScreen extends StatefulWidget {
  const ApplicationStatusScreen({super.key});

  @override
  State<ApplicationStatusScreen> createState() =>
      _ApplicationStatusScreenState();
}

class _ApplicationStatusScreenState extends State<ApplicationStatusScreen> {
  final _client = Supabase.instance.client;
  List<Map<String, dynamic>> _applications = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final user = _client.auth.currentUser;
      if (user == null) throw Exception('Not logged in.');

      final profile = await _client
          .from('profiles')
          .select('id')
          .eq('auth_user_id', user.id)
          .single();

      final rows = await _client
          .from('applications')
          .select(
            'application_id, application_date, status, admin_notes, '
            'learners(full_name, grade)',
          )
          .eq('parent_id', profile['id'])
          .order('application_date', ascending: false);

      if (!mounted) return;
      setState(() {
        _applications = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load applications: $e')),
      );
    }
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Your Applications')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  AppButton(
                    text: 'Start New Application',
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ApplicationWizardScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (_applications.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(30),
                      child: Center(
                        child: Text('No applications submitted yet.'),
                      ),
                    ),
                  ..._applications.map((a) {
                    final learner =
                        Map<String, dynamic>.from(a['learners'] ?? {});
                    final status = '${a['status'] ?? 'Pending'}';
                    return Card(
                      child: ListTile(
                        title: Text('${learner['full_name'] ?? 'Learner'}'),
                        subtitle: Text(
                          '${learner['grade'] ?? ''}\n'
                          'Submitted: ${a['application_date'] ?? ''}',
                        ),
                        isThreeLine: true,
                        trailing: Text(
                          status,
                          style: TextStyle(
                            color: _statusColor(status),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
    );
  }
}
