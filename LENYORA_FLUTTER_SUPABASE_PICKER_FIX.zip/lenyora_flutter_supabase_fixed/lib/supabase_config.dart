class SupabaseConfig {
  // IMPORTANT:
  // Use the URL from the SAME Supabase project where you created
  // profiles, learners, applications, documents, announcements and subjects.
  static const url = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';

  // Use the public anon/publishable key. NEVER use service_role here.
  static const anonKey = 'PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE';
}
