import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient client = Supabase.instance.client;

  User? get currentUser => client.auth.currentUser;

  Future<void> signUp({
    required String fullName,
    required String phoneNumber,
    required String email,
    required String password,
  }) async {
    final response = await client.auth.signUp(
      email: email.trim(),
      password: password,
      data: {
        'full_name': fullName.trim(),
        'phone_number': phoneNumber.trim(),
      },
    );

    final user = response.user;
    if (user == null) {
      throw const AuthException('Registration did not create a user.');
    }

    if (response.session != null) {
      await ensureProfile(
        fullName: fullName,
        phoneNumber: phoneNumber,
      );
    }
  }

  Future<void> ensureProfile({
    String? fullName,
    String? phoneNumber,
  }) async {
    final user = currentUser;
    if (user == null) {
      throw const AuthException('No signed-in user.');
    }

    final existing = await client
        .from('profiles')
        .select('id, full_name, phone_number, role, auth_user_id')
        .eq('auth_user_id', user.id)
        .maybeSingle();

    if (existing == null) {
      await client.from('profiles').insert({
        'auth_user_id': user.id,
        'full_name': (fullName ?? user.userMetadata?['full_name'] ?? '').toString(),
        'phone_number':
            (phoneNumber ?? user.userMetadata?['phone_number'] ?? '').toString(),
        'role': 'parent',
      });
    }
  }

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await client.auth.signInWithPassword(
      email: email.trim(),
      password: password,
    );
    await ensureProfile();
  }

  Future<void> signOut() => client.auth.signOut();

  Future<Map<String, dynamic>> getMyProfile() async {
    await ensureProfile();
    final user = currentUser!;
    final row = await client
        .from('profiles')
        .select()
        .eq('auth_user_id', user.id)
        .single();
    return Map<String, dynamic>.from(row);
  }
}
