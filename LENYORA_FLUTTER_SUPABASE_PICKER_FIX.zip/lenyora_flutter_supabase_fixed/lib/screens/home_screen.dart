import 'package:flutter/material.dart';
import 'announcements_screen.dart';
import 'application_status_screen.dart';
import 'application_wizard_screen.dart';
import 'profile_screen.dart';
import 'subjects_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<String> _name() async {
    try {
      final p = await AuthService().getMyProfile();
      return (p['full_name'] ?? 'Parent').toString();
    } catch (_) {
      return 'Parent';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            FutureBuilder<String>(
              future: _name(),
              builder: (context, snapshot) {
                return Container(
                  width: double.infinity,
                  color: AppTheme.maroon,
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Hello, ${snapshot.data ?? 'Parent'}!',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'Welcome to Lenyora Primary School',
                        style: TextStyle(color: Colors.white, fontSize: 11),
                      ),
                    ],
                  ),
                );
              },
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _HomeCard(
                          color: const Color(0xFFF1DE5B),
                          icon: Icons.campaign,
                          title: 'Announcements',
                          subtitle: 'Latest school news',
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const AnnouncementsScreen(),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _HomeCard(
                          color: const Color(0xFF579B46),
                          icon: Icons.menu_book,
                          title: 'Subjects',
                          subtitle: 'Subjects by grade',
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const SubjectsScreen(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _HomeCard(
                          color: const Color(0xFF55A7B2),
                          icon: Icons.description,
                          title: 'New Application',
                          subtitle: 'Apply for your child',
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ApplicationWizardScreen(),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _HomeCard(
                          color: const Color(0xFF5A58B7),
                          icon: Icons.assignment,
                          title: 'My Applications',
                          subtitle: 'Track status',
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ApplicationStatusScreen(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const SizedBox(height: 12),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Latest Announcements', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                    TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnnouncementsScreen())), child: const Text('View All')),
                  ]),
                  const _LatestAnnouncementPreview(),
                  const SizedBox(height: 8),
                  _HomeCard(
                    color: const Color(0xFFE7E7E7),
                    icon: Icons.person,
                    title: 'Profile',
                    subtitle: 'Manage your account',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ProfileScreen()),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeCard extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _HomeCard({
    required this.color,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 110,
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 30),
            const SizedBox(height: 6),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
            ),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 8),
            ),
          ],
        ),
      ),
    );
  }
}

class _LatestAnnouncementPreview extends StatefulWidget {
  const _LatestAnnouncementPreview();
  @override State<_LatestAnnouncementPreview> createState() => _LatestAnnouncementPreviewState();
}

class _LatestAnnouncementPreviewState extends State<_LatestAnnouncementPreview> {
  String _title = 'Welcome to Lenyora Primary School';
  String _description = 'Check announcements regularly for application dates, school events and important notices.';
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try {
      final rows = await Supabase.instance.client.from('announcements').select('title, description').eq('status', 'published').order('opening_date', ascending: false).limit(1);
      if (!mounted || rows.isEmpty) return;
      setState(() { _title = '${rows.first['title'] ?? _title}'; _description = '${rows.first['description'] ?? _description}'; });
    } catch (_) {}
  }
  @override Widget build(BuildContext context) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.info_outline, color: AppTheme.maroon, size: 26),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 5), Text(_description, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),])),
    ])),
  );
}
