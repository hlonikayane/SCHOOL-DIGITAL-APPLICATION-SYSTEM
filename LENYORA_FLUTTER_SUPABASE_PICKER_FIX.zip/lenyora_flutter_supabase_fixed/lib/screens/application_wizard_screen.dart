import 'package:flutter/material.dart';
import '../models/application_draft.dart';
import 'application_applicant_screen.dart';

class ApplicationWizardScreen extends StatefulWidget {
  const ApplicationWizardScreen({super.key});

  @override
  State<ApplicationWizardScreen> createState() =>
      _ApplicationWizardScreenState();
}

class _ApplicationWizardScreenState extends State<ApplicationWizardScreen> {
  final draft = ApplicationDraft();

  @override
  Widget build(BuildContext context) {
    return ApplicationApplicantScreen(draft: draft);
  }
}
