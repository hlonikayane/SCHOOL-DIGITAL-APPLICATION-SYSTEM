class ApplicationDraft {
  // Applicant
  String parentFullName = '';
  String parentIdNumber = '';
  String parentEmail = '';
  String parentPhone = '';
  String relationship = '';
  String parentAddress = '';

  // Learner
  String learnerFullName = '';
  String dateOfBirth = '';
  String gender = '';
  String currentSchool = '';
  String homeLanguage = '';
  String learnerAddress = '';
  String age = '';
  String grade = '';

  // Medical
  String medicalCondition = '';
  String doctorNameContact = '';
  String medicalAidNameNumber = '';
  String emergencyContactName = '';
  String emergencyContactPhone = '';
  String disability = '';

  final Map<String, String> documentPaths = {};
}
