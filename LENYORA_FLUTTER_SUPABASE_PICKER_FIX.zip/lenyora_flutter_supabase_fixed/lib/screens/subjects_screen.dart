import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SubjectsScreen extends StatefulWidget {
  const SubjectsScreen({super.key});

  @override
  State<SubjectsScreen> createState() => _SubjectsScreenState();
}

class _SubjectsScreenState extends State<SubjectsScreen> {
  final _client = Supabase.instance.client;
  String _grade = 'All';
  List<Map<String, dynamic>> _subjects = [];
  bool _loading = true;

  final grades = const [
    'All',
    'Grade R',
    'Grade 1',
    'Grade 2',
    'Grade 3',
    'Grade 4',
    'Grade 5',
    'Grade 6',
    'Grade 7',
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      var query = _client.from('subjects').select().order('grade').order('subject_name');
      final rows = _grade == 'All'
          ? await query
          : await _client
              .from('subjects')
              .select()
              .eq('grade', _grade)
              .order('subject_name');
      if (!mounted) return;
      var loaded = List<Map<String, dynamic>>.from(rows);
      if (loaded.isEmpty) {
        const defaults = <String, List<String>>{
          'Grade R': ['Sesotho', 'Mathematics', 'Life Skills'],
          'Grade 1': ['English', 'Numeracy', 'Life Skills', 'Sesotho'],
          'Grade 2': ['English', 'Mathematics', 'Life Skills', 'Sesotho'],
          'Grade 3': ['English', 'Mathematics', 'Life Skills', 'Sesotho'],
          'Grade 4': ['English', 'Mathematics', 'Life Skills', 'Social Sciences', 'Sesotho', 'Natural Sciences & Technology'],
          'Grade 5': ['English', 'Mathematics', 'Life Skills', 'Social Sciences', 'Sesotho', 'Natural Sciences & Technology'],
          'Grade 6': ['English', 'Mathematics', 'Life Skills', 'Social Sciences', 'Sesotho', 'Natural Sciences & Technology'],
          'Grade 7': ['English', 'Mathematics', 'Life Orientation', 'Social Sciences', 'Sesotho', 'Natural Sciences & Technology', 'Creative Arts', 'Economic & Management Sciences'],
        };
        final selectedGrades = _grade == 'All' ? defaults.keys : <String>[_grade];
        loaded = [for (final g in selectedGrades) for (final subject in defaults[g] ?? const <String>[]) {'grade': g, 'subject_name': subject}];
      }
      setState(() {
        _subjects = loaded;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load subjects: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Subjects')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: DropdownButtonFormField<String>(
              value: _grade,
              decoration: const InputDecoration(labelText: 'Filter by grade'),
              items: grades
                  .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                  .toList(),
              onChanged: (v) {
                setState(() => _grade = v ?? 'All');
                _load();
              },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _subjects.isEmpty
                    ? const Center(child: Text('No subjects found.'))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
                        itemCount: _subjects.length,
                        itemBuilder: (_, i) => Card(
                          child: ListTile(
                            leading: const Icon(Icons.menu_book, color: Color(0xFF842B2D)),
                            title: Text('${_subjects[i]['subject_name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text('${_subjects[i]['grade']}'),
                            trailing: const Icon(Icons.chevron_right),
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
