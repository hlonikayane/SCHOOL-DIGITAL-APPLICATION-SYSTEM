import 'package:flutter/material.dart';
import '../models/application_draft.dart';
import '../widgets/app_button.dart';
import '../widgets/app_text_field.dart';
import 'application_learner_screen.dart';

class ApplicationApplicantScreen extends StatefulWidget {
  final ApplicationDraft draft;
  const ApplicationApplicantScreen({super.key, required this.draft});

  @override
  State<ApplicationApplicantScreen> createState() =>
      _ApplicationApplicantScreenState();
}

class _ApplicationApplicantScreenState
    extends State<ApplicationApplicantScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController fullName;
  late final TextEditingController id;
  late final TextEditingController email;
  late final TextEditingController phone;
  late final TextEditingController relationship;
  late final TextEditingController address;

  @override
  void initState() {
    super.initState();
    final d = widget.draft;
    fullName = TextEditingController(text: d.parentFullName);
    id = TextEditingController(text: d.parentIdNumber);
    email = TextEditingController(text: d.parentEmail);
    phone = TextEditingController(text: d.parentPhone);
    relationship = TextEditingController(text: d.relationship);
    address = TextEditingController(text: d.parentAddress);
  }

  @override
  void dispose() {
    for (final c in [fullName, id, email, phone, relationship, address]) {
      c.dispose();
    }
    super.dispose();
  }

  void _next() {
    if (!_formKey.currentState!.validate()) return;
    final d = widget.draft;
    d.parentFullName = fullName.text.trim();
    d.parentIdNumber = id.text.trim();
    d.parentEmail = email.text.trim();
    d.parentPhone = phone.text.trim();
    d.relationship = relationship.text.trim();
    d.parentAddress = address.text.trim();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ApplicationLearnerScreen(draft: d),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Application - 1 of 4')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Text(
              '1. Parent/Guardian Details',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 12),
            AppTextField(
              label: 'Full name',
              controller: fullName,
              validator: requiredField,
            ),
            AppTextField(
              label: 'ID/Passport Number',
              controller: id,
              validator: requiredField,
            ),
            AppTextField(
              label: 'Email Address',
              controller: email,
              keyboardType: TextInputType.emailAddress,
              validator: (v) =>
                  (v == null || !v.contains('@')) ? 'Enter a valid email' : null,
            ),
            AppTextField(
              label: 'Phone Number',
              controller: phone,
              keyboardType: TextInputType.phone,
              validator: requiredField,
            ),
            AppTextField(
              label: 'Relationship to learner',
              controller: relationship,
              validator: requiredField,
            ),
            AppTextField(
              label: 'Physical Address',
              controller: address,
              maxLines: 2,
              validator: requiredField,
            ),
            AppButton(text: 'Next', onPressed: _next),
          ],
        ),
      ),
    );
  }
}

String? requiredField(String? value) {
  if (value == null || value.trim().isEmpty) return 'This field is required';
  return null;
}
